"""Local DNG parameter recommendations; each RAW job runs in a bounded process."""
import json
import os
from pathlib import Path
import subprocess
import sys
import tempfile
import threading
import time

import streamlit as st

ROOT = Path(__file__).resolve().parents[1]
BUNDLE = ROOT / 'artifacts/model'
LABELS = {'Exposure':'曝光', 'Contrast':'对比度', 'Saturation':'饱和度',
          'Temperature':'色温', 'Tint':'色调', 'HighlightRecovery':'高光恢复（旧流程）'}


@st.cache_resource
def job_lock():
    # ponytail: one RAW job at a time; use a queue if remote multi-user support is needed.
    return threading.Lock()


def clear_prediction():
    st.session_state.pop('prediction', None)


def run_job(data):
    started=time.perf_counter()
    if not 0 < len(data) <= 128 * 1024 * 1024:
        raise ValueError('文件必须小于 128 MB。')
    with job_lock(), tempfile.TemporaryDirectory(prefix='shotsense-') as directory:
        folder = Path(directory)
        source, result, preview = [folder / name for name in ('input.dng','result.json','input.jpg')]
        source.write_bytes(data)
        env = dict(os.environ, OMP_NUM_THREADS='1', OPENBLAS_NUM_THREADS='1')
        process = subprocess.run([sys.executable, '-m', 'src.inference', str(source),
                                  '--bundle', str(BUNDLE), '--output', str(result), '--preview', str(preview)],
                                 cwd=ROOT, env=env, capture_output=True, text=True, timeout=60)
        if process.returncode:
            detail = process.stderr.strip().splitlines()[-1] if process.stderr.strip() else '无法解码 DNG'
            if 'camera white balance' in detail:
                detail='此 DNG 缺少有效的相机白平衡信息，当前模型不支持。'
            elif '40 megapixel' in detail:
                detail='图像超过 4000 万像素的处理上限。'
            raise ValueError(detail)
        payload=json.loads(result.read_text())
        payload['timing']['local_worker_seconds']=time.perf_counter()-started
        return payload, preview.read_bytes()


st.set_page_config(page_title='ShotSense · 调色参数建议', page_icon='📷', layout='wide')
st.title('ShotSense')
st.write('从未调色 DNG 提取图像特征，推荐曝光与色彩参数。')
st.info('研究原型 · 建议为绝对值，使用旧版 Camera Raw PV2003 参数。高光恢复不能直接映射为现代 Highlights；未通过验证的参数会单列为实验输出。')

if not (BUNDLE / 'model.json').exists():
    st.warning('模型尚未准备好。请先完成全量训练和 ONNX 导出。')
    st.code('venv/bin/python -m src.train\nvenv/bin/python -m src.export_onnx')
    st.stop()

upload = st.file_uploader('上传未调色 DNG', type=['dng'], on_change=clear_prediction,
                          help='最大 128 MB、4000 万像素；本地处理，不上传远程服务器。')
left, right = st.columns(2)
analyze = left.button('生成参数建议', type='primary', disabled=upload is None)
sample = right.button('使用项目样例')
if analyze or sample:
    clear_prediction()
    try:
        with st.spinner('正在读取 RAW、提取特征并推理…'):
            data = upload.getvalue() if analyze else next(iter(sorted((ROOT / 'data/raw/dngs').glob('*.dng')))).read_bytes()
            st.session_state.prediction = run_job(data)
            st.session_state.prediction[0]['input_name']=upload.name if analyze else '项目样例'
    except subprocess.TimeoutExpired:
        st.error('处理超过 60 秒，任务已终止。请使用较小的 DNG。')
    except (ValueError, OSError, StopIteration) as error:
        st.error('处理失败：' + str(error))

if 'prediction' in st.session_state:
    result, preview = st.session_state.prediction
    st.caption('当前结果：' + result.get('input_name','DNG'))
    image_column, parameter_column = st.columns([3, 2])
    with image_column:
        st.image(preview, caption='输入的基准显影（224 × 224）。此图尚未应用推荐参数。', width=560)
    with parameter_column:
        st.subheader('参数建议')
        if result['recommended_absolute']:
            for name, value in result['recommended_absolute'].items():
                st.metric(LABELS[name], f"{value:.2f} {result['units'][name]}")
            st.caption('这些参数在固定验证集上优于训练集中位数基线，业务可接受误差尚未标定。')
        else:
            st.warning('当前模型没有通过验证的参数，所有输出仅供实验。')
        with st.expander('实验输出'):
            for name, value in result['experimental_absolute'].items():
                st.write(f"{LABELS[name]}：{value:.2f} {result['units'][name]}")
        st.download_button('下载参数 JSON', json.dumps(result, ensure_ascii=False, indent=2),
                           file_name='shotsense-parameters.json', mime='application/json')
        st.caption(f"本地任务 {result['timing']['local_worker_seconds']:.2f} 秒 · RAW 到结果 {result['timing']['end_to_end_seconds']:.2f} 秒 · 模型 {result['timing']['model_forward_ms']:.1f} 毫秒")
        st.caption('模型版本：' + result['model_sha256'][:16])
