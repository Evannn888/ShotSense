from pathlib import Path
import pytest
from streamlit.testing.v1 import AppTest

ROOT=Path(__file__).resolve().parents[1]


def test_local_app_sample_inference_and_download():
    if not (ROOT/'artifacts/model/model.json').exists():
        pytest.skip('Complete full training and export before application acceptance')
    at=AppTest.from_file(str(ROOT/'app/streamlit_app.py')).run(timeout=30)
    assert not at.exception
    next(button for button in at.button if button.label=='使用项目样例').click().run(timeout=60)
    assert not at.exception and not at.error
    result,preview=at.session_state['prediction']
    assert len(preview)>1000 and len(result['recommended_absolute'])+len(result['experimental_absolute'])==6
    assert at.get('download_button')
